import React from 'react';

class MessageList extends React.Component {

    render () {
        return(
            <ul>
                {this.props.messages.map((message, ind) => {
                    return <li key={ind}>
                        <div>
                            <span>{message.senderId}</span>
                            <p>{message.text}</p>
                        </div>
                    </li>
                    }    
                )}
            </ul>
        )
    }

}

export default MessageList;