import React from 'react';

class UsernameForm extends React.Component {

    state = {
        username: ''
    }

    onChange = (e) => {
        this.setState({
            username: e.target.value
        })
    }

    onSubmit = (e) => {
        e.preventDefault()
        this.props.onSubmit(this.state.username)
    }

    render(){
        return(
            <div>
                <form onSubmit={e => this.onSubmit(e)}>
                    <input type="text" placeholder="What is your username?" onChange={e => this.onChange(e)} />
                    <input type="submit" />
                </form>
            </div>
        )
    }
}

export default UsernameForm