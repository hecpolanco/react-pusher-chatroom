import React from 'react';

class SendMessageForm extends React.Component {

    state = {
        text: ''
    }

    onChange = (e) => {
        this.setState({
            text: e.target.value
        })
        this.props.onChange()
    }

    onSubmit = (e) => {
        e.preventDefault()
        this.props.onSubmit(this.state.text)
    }

    render(){
        return(
            <div>
                <form onSubmit={e => this.onSubmit(e)}>
                    <input type="text" placeholder="What is your text?" onChange={e => this.onChange(e)} />
                    <input type="submit" />
                </form>
            </div>
        )
    }
}

export default SendMessageForm